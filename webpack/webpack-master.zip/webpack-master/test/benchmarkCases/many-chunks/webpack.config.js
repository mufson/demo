module.exports = {
	entry: "./index"
}
