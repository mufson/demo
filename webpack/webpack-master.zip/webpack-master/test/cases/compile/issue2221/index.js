it("should compile non-immutable exports with missing semicolons", function(){
    require("./exportvar");
});
