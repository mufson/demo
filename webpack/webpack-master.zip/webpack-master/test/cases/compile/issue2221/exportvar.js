export var foo = "bar"
