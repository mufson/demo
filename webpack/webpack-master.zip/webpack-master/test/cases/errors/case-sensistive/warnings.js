module.exports = [
	[/There are multiple modules with names that only differ in casing/, /case-sensistive.A\.js/, /case-sensistive.a\.js/],
	[/There are multiple modules with names that only differ in casing/, /case-sensistive.B.file\.js/, /case-sensistive.b.file\.js/]
];
