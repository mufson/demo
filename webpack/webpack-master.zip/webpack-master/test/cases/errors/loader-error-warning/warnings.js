module.exports = [
	[
		/xyz/,
		/Emitted value instead of an instance of Error/,
		/warning-loader\.js/
	]
];
