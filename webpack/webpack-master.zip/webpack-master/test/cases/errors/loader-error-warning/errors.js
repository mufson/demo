module.exports = [
	[
		/abc/,
		/Emitted value instead of an instance of Error/,
		/error-loader\.js/
	],
	[
		/def/,
		/Emitted value instead of an instance of Error/,
		/error-loader\.js/
	]
];
