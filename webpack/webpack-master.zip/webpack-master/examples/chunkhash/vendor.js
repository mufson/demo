// some vendor lib (should be in common chunk)
export default 123;
