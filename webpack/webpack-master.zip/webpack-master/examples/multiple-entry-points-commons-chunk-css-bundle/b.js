require("./style.css");
require("./styleB.css");
